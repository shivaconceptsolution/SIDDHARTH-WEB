package bao;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import dao.SI;

@Controller
public class SIController {
@RequestMapping("/siview")	
public ModelAndView siLoad()
{
	return new ModelAndView("siview","command",new SI());
}
@RequestMapping("/silogic")	
public ModelAndView siLogic(@ModelAttribute("siddharthweb")SI obj, ModelMap model)
{
	float si = (obj.getP()*obj.getR()*obj.getT())/100;
	return new ModelAndView("siresult","msg",si);
}

}
